# Action Panel System - Plan Implementacji

> System zarządzania overlay'ami (drawer, dialog, sheet, panel) dla React + shadcn/ui
> 
> **Autor:** Claude Code Implementation Plan  
> **Wersja:** 1.0  
> **Stack:** React 18+, TypeScript, shadcn/ui, Tailwind CSS

---

## 📋 Spis treści

1. [Cel projektu](#cel-projektu)
2. [Architektura](#architektura)
3. [API Design](#api-design)
4. [Struktura plików](#struktura-plików)
5. [Wymagania implementacyjne](#wymagania-implementacyjne)
6. [Przykład kompletnego flow](#przykład-kompletnego-flow)
7. [Zależności](#zależności)
8. [Testy](#testy)
9. [Checklist implementacji](#checklist-implementacji)

---

## Cel projektu

Stworzyć system zarządzania overlay'ami który:

- ✅ **Jeden root renderingu** - wszystkie overlay'e renderowane w jednym miejscu (Provider)
- ✅ **Stack management** - stos otwartych overlay'ów, Escape zamyka ostatni (LIFO)
- ✅ **Deklaratywne hooki** - stan lokalny kontroluje otwarcie, bez imperatywnych `open()`
- ✅ **Host + Content pattern** - bazowy drawer/dialog hostuje różne formularze
- ✅ **Action registration** - dzieci mogą rejestrować przyciski w footerze hosta
- ✅ **Type-safe** - pełne wsparcie TypeScript

---

## Architektura

```
┌─────────────────────────────────────────────────────────────┐
│                      ActionProvider                          │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  • Renderuje wszystkie zarejestrowane overlay'e     │    │
│  │  • Zarządza stosem (stack) dla Escape handling      │    │
│  │  • Dostarcza context dla hooków                     │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│              useActionPanel(Component, options)              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  • Rejestruje panel w SYSTEMIE                      │    │
│  │  • Kontrolowany stanem LOKALNYM (deklaratywnie)     │    │
│  │  • Zwraca { isOpen, data }                          │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                       useActionHost()                        │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  • Używany WEWNĄTRZ renderowanego contentu          │    │
│  │  • Dostęp do: close, submit, registerAction         │    │
│  │  • Pozwala dziecku dodać PRZYCISKI do footera       │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

### Diagram przepływu danych

```
[User Click] 
    │
    ▼
[setState({ open: true, data })]  ←── stan LOKALNY w komponencie
    │
    ▼
[useActionPanel detects isOpen=true]
    │
    ▼
[Registers panel in ActionProvider]
    │
    ▼
[ActionProvider renders overlay]
    │
    ▼
[Child component uses useActionHost]
    │
    ▼
[registerAction() adds buttons to footer]
    │
    ▼
[User clicks action → close() → setState({ open: false })]
    │
    ▼
[useActionPanel detects isOpen=false]
    │
    ▼
[Unregisters panel from ActionProvider]
```

---

## API Design

### 1. ActionProvider - Root Component

```tsx
// app/layout.tsx lub App.tsx
import { ActionProvider } from '@/lib/actions';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html>
      <body>
        <ActionProvider>
          {children}
        </ActionProvider>
      </body>
    </html>
  );
}
```

**Props:**

| Prop | Type | Default | Opis |
|------|------|---------|------|
| `children` | `ReactNode` | required | Aplikacja |
| `defaultVariant` | `'drawer' \| 'dialog' \| 'sheet'` | `'sheet'` | Domyślny typ overlay |

---

### 2. useActionPanel - Hook rejestracji panelu

```tsx
function useActionPanel<TData>(
  Component: React.ComponentType<ActionContentProps<TData>>,
  options: ActionPanelOptions<TData>
): void;
```

**ActionPanelOptions:**

```tsx
type ActionPanelOptions<TData> = {
  // Wymagane
  isOpen: boolean;
  onClose: () => void;
  
  // Dane przekazywane do Component
  data?: TData;
  
  // Konfiguracja hosta
  title?: string;
  description?: string;
  variant?: 'drawer' | 'dialog' | 'sheet';
  side?: 'left' | 'right' | 'top' | 'bottom';
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  
  // Domyślne akcje (można nadpisać z dziecka)
  actions?: ActionConfig[];
  
  // Callbacks
  onSubmit?: (data: unknown) => void | Promise<void>;
  
  // Opcje zachowania
  closeOnEscape?: boolean;      // default: true
  closeOnOverlay?: boolean;     // default: true
  preventScroll?: boolean;      // default: true
};
```

**ActionContentProps:**

```tsx
type ActionContentProps<TData> = {
  data: TData;
};
```

**Przykład użycia:**

```tsx
function UsersPage() {
  const [editingUser, setEditingUser] = useState<User | null>(null);

  useActionPanel(UserEditForm, {
    isOpen: editingUser !== null,
    onClose: () => setEditingUser(null),
    data: editingUser,
    title: 'Edytuj użytkownika',
    variant: 'sheet',
    side: 'right',
    size: 'md',
  });

  return (
    <UserList onEdit={(user) => setEditingUser(user)} />
  );
}
```

---

### 3. useActionHost - Hook dla dziecka

```tsx
function useActionHost<TSubmitData = void>(): ActionHostContext<TSubmitData>;
```

**ActionHostContext:**

```tsx
type ActionHostContext<TSubmitData> = {
  // Podstawowe akcje
  close: () => void;
  submit: (data: TSubmitData) => Promise<void>;
  
  // Rejestracja akcji w footerze
  registerAction: (action: ActionConfig) => () => void;
  clearActions: () => void;
  
  // Aktualizacja hosta
  setTitle: (title: string) => void;
  setDescription: (description: string) => void;
  setLoading: (loading: boolean) => void;
  
  // Stan
  isSubmitting: boolean;
  isLoading: boolean;
};
```

**ActionConfig:**

```tsx
type ActionConfig = {
  id: string;
  label: string;
  onClick: () => void | Promise<void>;
  variant?: 'default' | 'destructive' | 'outline' | 'ghost' | 'secondary';
  position?: 'left' | 'right';
  loading?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
};
```

**Przykład użycia:**

```tsx
function UserEditForm({ data: user }: { data: User }) {
  const { close, registerAction, setLoading } = useActionHost();
  const [formData, setFormData] = useState(user);

  useEffect(() => {
    const unregisterSave = registerAction({
      id: 'save',
      label: 'Zapisz',
      variant: 'default',
      position: 'right',
      onClick: async () => {
        setLoading(true);
        try {
          await api.updateUser(user.id, formData);
          toast.success('Zapisano!');
          close();
        } finally {
          setLoading(false);
        }
      },
    });

    const unregisterCancel = registerAction({
      id: 'cancel',
      label: 'Anuluj',
      variant: 'outline',
      position: 'left',
      onClick: close,
    });

    return () => {
      unregisterSave();
      unregisterCancel();
    };
  }, [formData, user.id]);

  return (
    <form>
      <Input
        value={formData.name}
        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
      />
    </form>
  );
}
```

---

### 4. useDrawerState - Helper hook

```tsx
function useDrawerState<TData = void>(): {
  isOpen: boolean;
  data: TData | null;
  open: (data?: TData) => void;
  close: () => void;
};
```

**Przykład użycia:**

```tsx
function MyPage() {
  const userEdit = useDrawerState<User>();

  useActionPanel(UserEditForm, {
    isOpen: userEdit.isOpen,
    onClose: userEdit.close,
    data: userEdit.data,
    title: 'Edytuj',
    variant: 'sheet',
  });

  return (
    <button onClick={() => userEdit.open(someUser)}>
      Edit
    </button>
  );
}
```

---

## Struktura plików

```
src/
├── lib/
│   └── actions/
│       ├── index.ts                    # Eksporty publiczne
│       │
│       ├── types.ts                    # Wszystkie typy TypeScript
│       │
│       ├── context/
│       │   ├── action-context.ts       # ActionContext definition
│       │   └── host-context.ts         # ActionHostContext definition
│       │
│       ├── provider/
│       │   ├── action-provider.tsx     # Główny provider
│       │   └── stack-manager.ts        # Logika zarządzania stosem
│       │
│       ├── hooks/
│       │   ├── use-action-panel.ts     # Hook rejestracji panelu
│       │   ├── use-action-host.ts      # Hook dla dziecka
│       │   ├── use-drawer-state.ts     # Helper hook
│       │   └── use-escape-handler.ts   # Hook dla Escape key
│       │
│       └── components/
│           ├── action-host.tsx         # Wrapper hosta (header, content, footer)
│           ├── action-footer.tsx       # Footer z akcjami
│           └── action-overlay.tsx      # Wrapper dla różnych variant'ów
```

### Eksporty (index.ts)

```tsx
// Provider
export { ActionProvider } from './provider/action-provider';

// Hooks
export { useActionPanel } from './hooks/use-action-panel';
export { useActionHost } from './hooks/use-action-host';
export { useDrawerState } from './hooks/use-drawer-state';

// Types
export type {
  ActionConfig,
  ActionPanelOptions,
  ActionContentProps,
  ActionHostContext,
} from './types';
```

---

## Wymagania implementacyjne

### 1. Stack Management (Escape handling)

```tsx
// types.ts
type StackItem = {
  id: string;
  close: () => void;
  zIndex: number;
  closeOnEscape: boolean;
};

// stack-manager.ts
class StackManager {
  private stack: StackItem[] = [];
  private listeners: Set<() => void> = new Set();

  push(item: StackItem) {
    this.stack.push(item);
    this.notify();
  }

  pop(id?: string) {
    if (id) {
      this.stack = this.stack.filter(item => item.id !== id);
    } else {
      this.stack.pop();
    }
    this.notify();
  }

  getTop(): StackItem | undefined {
    return this.stack[this.stack.length - 1];
  }

  getZIndex(id: string): number {
    const index = this.stack.findIndex(item => item.id === id);
    return 50 + (index * 10);
  }

  subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach(listener => listener());
  }
}

// use-escape-handler.ts
function useEscapeHandler(stackManager: StackManager) {
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        const top = stackManager.getTop();
        if (top?.closeOnEscape) {
          e.preventDefault();
          top.close();
        }
      }
    };
    
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [stackManager]);
}
```

### 2. Z-Index Management

```tsx
// Bazowy z-index: 50
// Każdy kolejny panel: +10
// Overlay każdego: z-index panelu - 1

const Z_INDEX_BASE = 50;
const Z_INDEX_STEP = 10;

function getZIndex(stackPosition: number): {
  overlay: number;
  content: number;
} {
  const base = Z_INDEX_BASE + (stackPosition * Z_INDEX_STEP);
  return {
    overlay: base,
    content: base + 1,
  };
}
```

### 3. ActionHost Component

```tsx
// action-host.tsx
import { SheetHeader, SheetTitle, SheetDescription, SheetFooter } from '@/components/ui/sheet';

type ActionHostProps = {
  children: React.ReactNode;
  config: {
    title?: string;
    description?: string;
    actions?: ActionConfig[];
  };
  panelId: string;
  onClose: () => void;
};

export function ActionHost({ children, config, panelId, onClose }: ActionHostProps) {
  const [title, setTitle] = useState(config.title);
  const [description, setDescription] = useState(config.description);
  const [actions, setActions] = useState<ActionConfig[]>(config.actions ?? []);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const registerAction = useCallback((action: ActionConfig) => {
    setActions(prev => {
      // Usuń jeśli już istnieje (update)
      const filtered = prev.filter(a => a.id !== action.id);
      return [...filtered, action];
    });
    
    // Zwróć funkcję unregister
    return () => {
      setActions(prev => prev.filter(a => a.id !== action.id));
    };
  }, []);

  const clearActions = useCallback(() => {
    setActions([]);
  }, []);

  const hostContext: ActionHostContext = useMemo(() => ({
    close: onClose,
    submit: async (data) => {
      setIsSubmitting(true);
      try {
        await config.onSubmit?.(data);
        onClose();
      } finally {
        setIsSubmitting(false);
      }
    },
    registerAction,
    clearActions,
    setTitle,
    setDescription,
    setLoading: setIsLoading,
    isSubmitting,
    isLoading,
  }), [onClose, registerAction, clearActions, isSubmitting, isLoading]);

  return (
    <ActionHostContext.Provider value={hostContext}>
      {/* Header */}
      {(title || description) && (
        <SheetHeader>
          {title && <SheetTitle>{title}</SheetTitle>}
          {description && <SheetDescription>{description}</SheetDescription>}
        </SheetHeader>
      )}

      {/* Content */}
      <div className="flex-1 overflow-auto p-4">
        {children}
      </div>

      {/* Footer */}
      {actions.length > 0 && (
        <SheetFooter>
          <ActionFooter actions={actions} isLoading={isLoading} />
        </SheetFooter>
      )}
    </ActionHostContext.Provider>
  );
}
```

### 4. ActionFooter Component

```tsx
// action-footer.tsx
import { Button } from '@/components/ui/button';

type ActionFooterProps = {
  actions: ActionConfig[];
  isLoading: boolean;
};

export function ActionFooter({ actions, isLoading }: ActionFooterProps) {
  const leftActions = actions.filter(a => a.position === 'left');
  const rightActions = actions.filter(a => a.position !== 'left');

  const renderAction = (action: ActionConfig) => (
    <Button
      key={action.id}
      variant={action.variant ?? 'default'}
      disabled={action.disabled || isLoading}
      onClick={action.onClick}
    >
      {action.loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
      {action.icon}
      {action.label}
    </Button>
  );

  return (
    <div className="flex justify-between gap-2">
      <div className="flex gap-2">
        {leftActions.map(renderAction)}
      </div>
      <div className="flex gap-2">
        {rightActions.map(renderAction)}
      </div>
    </div>
  );
}
```

### 5. Variant Support (ActionOverlay)

```tsx
// action-overlay.tsx
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Drawer, DrawerContent } from '@/components/ui/drawer';

type ActionOverlayProps = {
  variant: 'drawer' | 'dialog' | 'sheet';
  side?: 'left' | 'right' | 'top' | 'bottom';
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  open: boolean;
  onOpenChange: (open: boolean) => void;
  zIndex: number;
  children: React.ReactNode;
};

const SIZE_CLASSES = {
  sm: 'max-w-sm',
  md: 'max-w-md',
  lg: 'max-w-lg',
  xl: 'max-w-xl',
  full: 'max-w-full',
};

export function ActionOverlay({
  variant,
  side = 'right',
  size = 'md',
  open,
  onOpenChange,
  zIndex,
  children,
}: ActionOverlayProps) {
  const style = { zIndex };

  switch (variant) {
    case 'sheet':
      return (
        <Sheet open={open} onOpenChange={onOpenChange}>
          <SheetContent
            side={side}
            className={SIZE_CLASSES[size]}
            style={style}
          >
            {children}
          </SheetContent>
        </Sheet>
      );

    case 'dialog':
      return (
        <Dialog open={open} onOpenChange={onOpenChange}>
          <DialogContent className={SIZE_CLASSES[size]} style={style}>
            {children}
          </DialogContent>
        </Dialog>
      );

    case 'drawer':
      return (
        <Drawer open={open} onOpenChange={onOpenChange}>
          <DrawerContent style={style}>
            {children}
          </DrawerContent>
        </Drawer>
      );
  }
}
```

---

## Przykład kompletnego flow

### 1. Setup - Provider w Layout

```tsx
// app/layout.tsx
import { ActionProvider } from '@/lib/actions';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html>
      <body>
        <ActionProvider>
          {children}
        </ActionProvider>
      </body>
    </html>
  );
}
```

### 2. Strona - Używa hooków

```tsx
// app/orders/page.tsx
'use client';

import { useActionPanel, useDrawerState } from '@/lib/actions';
import { OrderForm } from '@/components/orders/order-form';
import { OrderList } from '@/components/orders/order-list';
import { Order } from '@/types';

export default function OrdersPage() {
  const editOrder = useDrawerState<Order>();
  const createOrder = useDrawerState<void>();

  // Panel edycji
  useActionPanel(OrderForm, {
    isOpen: editOrder.isOpen,
    onClose: editOrder.close,
    data: editOrder.data,
    title: 'Edytuj zamówienie',
    variant: 'sheet',
    side: 'right',
    size: 'lg',
  });

  // Panel tworzenia
  useActionPanel(OrderForm, {
    isOpen: createOrder.isOpen,
    onClose: createOrder.close,
    data: null,
    title: 'Nowe zamówienie',
    variant: 'sheet',
    side: 'right',
    size: 'lg',
  });

  return (
    <div className="p-6">
      <div className="flex justify-between mb-6">
        <h1 className="text-2xl font-bold">Zamówienia</h1>
        <Button onClick={() => createOrder.open()}>
          Nowe zamówienie
        </Button>
      </div>
      
      <OrderList onEdit={(order) => editOrder.open(order)} />
    </div>
  );
}
```

### 3. Formularz - Rejestruje akcje

```tsx
// components/orders/order-form.tsx
'use client';

import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useActionHost } from '@/lib/actions';
import { Order, OrderFormData } from '@/types';
import { api } from '@/lib/api';
import { toast } from 'sonner';

type OrderFormProps = {
  data: Order | null;
};

export function OrderForm({ data: order }: OrderFormProps) {
  const { close, registerAction, setTitle, setLoading } = useActionHost();
  const isEdit = order !== null;
  
  const form = useForm<OrderFormData>({
    defaultValues: order ?? {
      customerName: '',
      items: [],
      status: 'pending',
    },
  });

  // Dynamiczny tytuł
  useEffect(() => {
    if (isEdit && order) {
      setTitle(`Zamówienie #${order.id}`);
    }
  }, [isEdit, order, setTitle]);

  // Rejestruj akcje w footerze
  useEffect(() => {
    const unsubscribers = [
      // Przycisk Anuluj (lewa strona)
      registerAction({
        id: 'cancel',
        label: 'Anuluj',
        variant: 'outline',
        position: 'left',
        onClick: close,
      }),
      
      // Przycisk Zapisz/Utwórz (prawa strona)
      registerAction({
        id: 'save',
        label: isEdit ? 'Zapisz zmiany' : 'Utwórz zamówienie',
        variant: 'default',
        position: 'right',
        onClick: form.handleSubmit(async (formData) => {
          setLoading(true);
          try {
            if (isEdit && order) {
              await api.orders.update(order.id, formData);
              toast.success('Zamówienie zostało zaktualizowane');
            } else {
              await api.orders.create(formData);
              toast.success('Zamówienie zostało utworzone');
            }
            close();
          } catch (error) {
            toast.error('Wystąpił błąd');
          } finally {
            setLoading(false);
          }
        }),
      }),
    ];

    // Cleanup - usuń akcje przy unmount
    return () => {
      unsubscribers.forEach(unsubscribe => unsubscribe());
    };
  }, [isEdit, order, form, close, registerAction, setLoading]);

  return (
    <Form {...form}>
      <div className="space-y-4">
        <FormField
          control={form.control}
          name="customerName"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Nazwa klienta</FormLabel>
              <FormControl>
                <Input {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {/* Więcej pól... */}
      </div>
    </Form>
  );
}
```

### 4. Nested panels - Panel w panelu

```tsx
// Przykład: Edycja zamówienia → Dodanie produktu

function OrderForm({ data: order }: { data: Order | null }) {
  const { registerAction } = useActionHost();
  const addProduct = useDrawerState<void>();

  // Panel dodawania produktu (nested)
  useActionPanel(ProductSelector, {
    isOpen: addProduct.isOpen,
    onClose: addProduct.close,
    data: null,
    title: 'Dodaj produkt',
    variant: 'sheet',
    side: 'right',
    size: 'md',
  });

  useEffect(() => {
    const unsubscribe = registerAction({
      id: 'add-product',
      label: 'Dodaj produkt',
      variant: 'secondary',
      position: 'left',
      onClick: () => addProduct.open(),
    });

    return unsubscribe;
  }, [registerAction, addProduct]);

  // ... rest of form
}
```

---

## Zależności

### Wymagane shadcn komponenty

```bash
# Instalacja komponentów shadcn
pnpm dlx shadcn@latest add sheet dialog button

# Drawer (opcjonalnie - jeśli używasz variant: 'drawer')
pnpm dlx shadcn@latest add drawer
```

### Opcjonalne zależności

```bash
# Jeśli potrzebujesz globalnego stanu poza React
pnpm add zustand

# Dla formularzy
pnpm add react-hook-form @hookform/resolvers zod

# Dla notyfikacji
pnpm add sonner
```

### Package.json (wymagane peer dependencies)

```json
{
  "dependencies": {
    "react": "^18.0.0",
    "react-dom": "^18.0.0",
    "@radix-ui/react-dialog": "^1.0.0",
    "vaul": "^0.9.0",
    "tailwindcss": "^3.0.0"
  }
}
```

---

## Testy

### 1. Unit Tests

```tsx
// __tests__/use-drawer-state.test.ts
describe('useDrawerState', () => {
  it('should initialize with closed state', () => {
    const { result } = renderHook(() => useDrawerState<string>());
    
    expect(result.current.isOpen).toBe(false);
    expect(result.current.data).toBeNull();
  });

  it('should open with data', () => {
    const { result } = renderHook(() => useDrawerState<string>());
    
    act(() => {
      result.current.open('test-data');
    });
    
    expect(result.current.isOpen).toBe(true);
    expect(result.current.data).toBe('test-data');
  });

  it('should close and clear data', () => {
    const { result } = renderHook(() => useDrawerState<string>());
    
    act(() => {
      result.current.open('test-data');
      result.current.close();
    });
    
    expect(result.current.isOpen).toBe(false);
    expect(result.current.data).toBeNull();
  });
});
```

### 2. Integration Tests

```tsx
// __tests__/action-panel.test.tsx
describe('ActionPanel', () => {
  it('should render panel when isOpen is true', () => {
    function TestComponent() {
      const [isOpen, setIsOpen] = useState(true);
      
      useActionPanel(TestContent, {
        isOpen,
        onClose: () => setIsOpen(false),
        title: 'Test Panel',
      });
      
      return null;
    }
    
    render(
      <ActionProvider>
        <TestComponent />
      </ActionProvider>
    );
    
    expect(screen.getByText('Test Panel')).toBeInTheDocument();
  });

  it('should close on Escape key', async () => {
    const onClose = vi.fn();
    
    function TestComponent() {
      useActionPanel(TestContent, {
        isOpen: true,
        onClose,
        title: 'Test Panel',
      });
      
      return null;
    }
    
    render(
      <ActionProvider>
        <TestComponent />
      </ActionProvider>
    );
    
    await userEvent.keyboard('{Escape}');
    
    expect(onClose).toHaveBeenCalled();
  });
});
```

### 3. Stack Management Tests

```tsx
// __tests__/stack-manager.test.ts
describe('StackManager', () => {
  it('should close last opened panel on Escape', async () => {
    const onClose1 = vi.fn();
    const onClose2 = vi.fn();
    
    function TestComponent() {
      useActionPanel(Content1, { isOpen: true, onClose: onClose1, title: 'Panel 1' });
      useActionPanel(Content2, { isOpen: true, onClose: onClose2, title: 'Panel 2' });
      return null;
    }
    
    render(
      <ActionProvider>
        <TestComponent />
      </ActionProvider>
    );
    
    await userEvent.keyboard('{Escape}');
    
    expect(onClose2).toHaveBeenCalled(); // Ostatni
    expect(onClose1).not.toHaveBeenCalled();
  });

  it('should maintain correct z-index order', () => {
    // Panel 1: z-index 50
    // Panel 2: z-index 60
    // Panel 3: z-index 70
  });
});
```

### 4. Action Registration Tests

```tsx
// __tests__/action-host.test.tsx
describe('useActionHost', () => {
  it('should register action in footer', () => {
    function FormContent() {
      const { registerAction } = useActionHost();
      
      useEffect(() => {
        return registerAction({
          id: 'save',
          label: 'Save',
          onClick: vi.fn(),
        });
      }, []);
      
      return <div>Form</div>;
    }
    
    // ... render and assert button appears in footer
  });

  it('should unregister action on cleanup', () => {
    // ... test that action is removed when component unmounts
  });
});
```

---

## Checklist implementacji

### Faza 1: Core Setup
- [ ] Utworzenie struktury plików
- [ ] Definicja typów w `types.ts`
- [ ] Implementacja `ActionContext`
- [ ] Implementacja `ActionHostContext`

### Faza 2: Provider
- [ ] Implementacja `ActionProvider`
- [ ] Implementacja `StackManager`
- [ ] Escape key handling
- [ ] Z-index management

### Faza 3: Hooks
- [ ] Implementacja `useActionPanel`
- [ ] Implementacja `useActionHost`
- [ ] Implementacja `useDrawerState`

### Faza 4: Components
- [ ] Implementacja `ActionHost`
- [ ] Implementacja `ActionFooter`
- [ ] Implementacja `ActionOverlay`
- [ ] Warianty (sheet, dialog, drawer)

### Faza 5: Polish
- [ ] Animacje i transitions
- [ ] Accessibility (aria-labels, focus management)
- [ ] Error boundaries
- [ ] Loading states

### Faza 6: Testing
- [ ] Unit tests dla hooków
- [ ] Integration tests dla komponentów
- [ ] E2E tests dla user flows
- [ ] Accessibility tests

### Faza 7: Documentation
- [ ] JSDoc dla wszystkich publicznych API
- [ ] README z przykładami
- [ ] Storybook stories

---

## Uwagi dodatkowe

### Performance

1. **useId()** - używaj dla unikalnych ID paneli
2. **useCallback** - `registerAction` musi być stabilne
3. **React.lazy** - rozważ dla dużych formularzy
4. **Memoization** - `useMemo` dla kontekstów

### Accessibility

1. **Focus management** - focus trap wewnątrz panelu
2. **aria-labels** - dla przycisków i sekcji
3. **Escape key** - zamykanie panelu
4. **Screen readers** - announcements dla otwarcia/zamknięcia

### Edge Cases

1. **Rapid open/close** - debounce jeśli potrzebne
2. **Form dirty state** - confirm przed zamknięciem
3. **Async actions** - loading states, error handling
4. **SSR** - upewnij się że działa z Next.js App Router

---

## Kontakt

W razie pytań podczas implementacji - opisz problem z kontekstem:
- Co próbujesz osiągnąć?
- Jaki błąd/problem występuje?
- Snippet kodu który nie działa

---

*Plan wygenerowany dla Claude Code - gotowy do implementacji*
