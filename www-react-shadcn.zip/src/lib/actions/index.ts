// Types
export type {
  PanelVariant,
  SheetSide,
  PanelSize,
  ActionConfig,
  ActionPanelOptions,
  ActionContentProps,
  ActionHostContextValue,
  ConfirmOptions,
  ConfirmResult,
  PanelRegistration,
  ActionFormHostProps,
} from './types';

// Provider
export { ActionProvider } from './provider/action-provider';

// Components
export { ActionHost } from './components/action-host';
export { ActionFooter } from './components/action-footer';
export { ActionOverlay } from './components/action-overlay';
export { ActionFormHost } from './components/action-form-host';
export { ConfirmDialog } from './components/confirm-dialog';

// Hooks
export { usePanelState, type PanelState } from './hooks/use-panel-state';
export { useActionPanel } from './hooks/use-action-panel';
export { useActionHost, useActionHostSafe } from './hooks/use-action-host';
export { useConfirm } from './hooks/use-confirm';
export { useFormDirty } from './hooks/use-form-dirty';

// Contexts (for advanced usage)
export { ActionContext, useActionContext } from './context/action-context';
export { HostContext, useHostContext, useHostContextSafe } from './context/host-context';
export { ConfirmContext, useConfirmContext } from './context/confirm-context';
