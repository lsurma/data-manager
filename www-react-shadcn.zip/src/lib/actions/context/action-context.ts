import { createContext, useContext } from 'react';
import type { PanelRegistration } from '../types';

export type ActionContextValue = {
  panels: Map<string, PanelRegistration>;
  registerPanel: (panel: PanelRegistration) => () => void;
  updatePanel: (id: string, updates: Partial<PanelRegistration>) => void;
  unregisterPanel: (id: string) => void;
};

export const ActionContext = createContext<ActionContextValue | null>(null);

export function useActionContext(): ActionContextValue {
  const context = useContext(ActionContext);
  if (!context) {
    throw new Error('useActionContext must be used within an ActionProvider');
  }
  return context;
}
