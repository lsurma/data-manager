import { createContext, useContext } from 'react';
import type { ConfirmOptions, ConfirmResult } from '../types';

export type ConfirmContextValue = {
  confirm: (options: ConfirmOptions) => Promise<ConfirmResult>;
};

export const ConfirmContext = createContext<ConfirmContextValue | null>(null);

export function useConfirmContext(): ConfirmContextValue {
  const context = useContext(ConfirmContext);
  if (!context) {
    throw new Error('useConfirmContext must be used within an ActionProvider');
  }
  return context;
}
