import { createContext, useContext } from 'react';
import type { ActionHostContextValue } from '../types';

export const HostContext = createContext<ActionHostContextValue | null>(null);

export function useHostContext(): ActionHostContextValue {
  const context = useContext(HostContext);
  if (!context) {
    throw new Error('useHostContext must be used within an ActionHost');
  }
  return context;
}

export function useHostContextSafe(): ActionHostContextValue | null {
  return useContext(HostContext);
}
