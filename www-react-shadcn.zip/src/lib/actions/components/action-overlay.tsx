import type * as React from 'react';
import * as VisuallyHidden from '@radix-ui/react-visually-hidden';
import {
  Sheet,
  SheetContent,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import type { PanelVariant, SheetSide, PanelSize } from '../types';

export type ActionOverlayProps = {
  variant: PanelVariant;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  side?: SheetSide;
  size?: PanelSize;
  closeOnEscape?: boolean;
  closeOnOverlay?: boolean;
  children: React.ReactNode;
};

const sheetSizeClasses: Record<PanelSize, string> = {
  sm: 'sm:max-w-sm',
  md: 'sm:max-w-md',
  lg: 'sm:max-w-lg',
  xl: 'sm:max-w-xl',
  full: 'sm:max-w-full',
};

const dialogSizeClasses: Record<PanelSize, string> = {
  sm: 'sm:max-w-sm',
  md: 'sm:max-w-md',
  lg: 'sm:max-w-lg',
  xl: 'sm:max-w-xl',
  full: 'sm:max-w-[calc(100vw-4rem)]',
};

export function ActionOverlay({
  variant,
  isOpen,
  onOpenChange,
  side = 'right',
  size = 'md',
  closeOnEscape = true,
  closeOnOverlay = true,
  children,
}: ActionOverlayProps) {
  const handleEscapeKeyDown = (e: KeyboardEvent) => {
    if (!closeOnEscape) {
      e.preventDefault();
    }
  };

  const handlePointerDownOutside = (e: Event) => {
    if (!closeOnOverlay) {
      e.preventDefault();
    }
  };

  const handleInteractOutside = (e: Event) => {
    if (!closeOnOverlay) {
      e.preventDefault();
    }
  };

  if (variant === 'dialog') {
    return (
      <Dialog open={isOpen} onOpenChange={onOpenChange}>
        <DialogContent
          className={cn('flex flex-col', dialogSizeClasses[size])}
          showCloseButton={false}
          onEscapeKeyDown={handleEscapeKeyDown}
          onPointerDownOutside={handlePointerDownOutside}
          onInteractOutside={handleInteractOutside}
          aria-describedby={undefined}
        >
          <VisuallyHidden.Root>
            <DialogTitle>Panel</DialogTitle>
            <DialogDescription>Panel akcji</DialogDescription>
          </VisuallyHidden.Root>
          {children}
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Sheet open={isOpen} onOpenChange={onOpenChange}>
      <SheetContent
        side={side}
        className={cn('flex flex-col p-0', sheetSizeClasses[size])}
        showCloseButton={false}
        onEscapeKeyDown={handleEscapeKeyDown}
        onPointerDownOutside={handlePointerDownOutside}
        onInteractOutside={handleInteractOutside}
        aria-describedby={undefined}
      >
        <VisuallyHidden.Root>
          <SheetTitle>Panel</SheetTitle>
          <SheetDescription>Panel akcji</SheetDescription>
        </VisuallyHidden.Root>
        {children}
      </SheetContent>
    </Sheet>
  );
}
