import { FormProvider, type UseFormReturn, type FieldValues } from 'react-hook-form';
import { useFormDirty } from '../hooks/use-form-dirty';

export type ActionFormHostProps<T extends FieldValues> = {
  form: UseFormReturn<T>;
  children: React.ReactNode;
};

function FormDirtySynchronizer<T extends FieldValues>({
  form,
  children,
}: ActionFormHostProps<T>) {
  useFormDirty(form);
  return <>{children}</>;
}

export function ActionFormHost<T extends FieldValues>({
  form,
  children,
}: ActionFormHostProps<T>) {
  return (
    <FormProvider {...form}>
      <FormDirtySynchronizer form={form}>{children}</FormDirtySynchronizer>
    </FormProvider>
  );
}
