import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import type { ConfirmOptions, ConfirmResult } from '../types';

export type ConfirmDialogProps = {
  open: boolean;
  options: ConfirmOptions;
  onResult: (result: ConfirmResult) => void;
};

export function ConfirmDialog({ open, options, onResult }: ConfirmDialogProps) {
  const {
    title,
    description,
    confirmLabel = 'Potwierdź',
    cancelLabel = 'Anuluj',
    variant = 'default',
  } = options;

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onResult('cancel')}>
      <DialogContent showCloseButton={false}>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => onResult('cancel')}>
            {cancelLabel}
          </Button>
          <Button
            variant={variant === 'destructive' ? 'destructive' : 'default'}
            onClick={() => onResult('confirm')}
          >
            {confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
