import { useState, useCallback, useMemo, type ReactNode } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { HostContext } from '../context/host-context';
import { useConfirm } from '../hooks/use-confirm';
import { ActionFooter } from './action-footer';
import { ActionOverlay } from './action-overlay';
import type {
  ActionConfig,
  ActionHostContextValue,
  ActionPanelOptions,
} from '../types';

export type ActionHostProps = {
  options: ActionPanelOptions;
  children: ReactNode;
};

export function ActionHost({ options, children }: ActionHostProps) {
  const {
    isOpen,
    onClose,
    title: initialTitle,
    description: initialDescription,
    variant = 'sheet',
    side = 'right',
    size = 'md',
    actions: initialActions = [],
    isDirty: externalIsDirty,
    onDirtyClose = 'confirm',
    closeOnEscape = true,
    closeOnOverlay = true,
  } = options;

  const confirm = useConfirm();

  // Internal state
  const [actions, setActions] = useState<ActionConfig[]>(initialActions);
  const [title, setTitle] = useState(initialTitle ?? '');
  const [description, setDescription] = useState(initialDescription ?? '');
  const [isLoading, setLoading] = useState(false);
  const [internalIsDirty, setInternalDirty] = useState(false);

  // isDirty: external override takes precedence
  const isDirty = externalIsDirty ?? internalIsDirty;

  const handleClose = useCallback(async () => {
    if (!isDirty) {
      onClose();
      return;
    }

    switch (onDirtyClose) {
      case 'allow':
        onClose();
        break;
      case 'block':
        // Do nothing - close is blocked
        break;
      case 'confirm':
      default: {
        const result = await confirm({
          title: 'Niezapisane zmiany',
          description: 'Masz niezapisane zmiany. Czy na pewno chcesz zamknąć?',
          confirmLabel: 'Odrzuć zmiany',
          cancelLabel: 'Wróć',
          variant: 'destructive',
        });
        if (result === 'confirm') {
          onClose();
        }
        break;
      }
    }
  }, [isDirty, onDirtyClose, onClose, confirm]);

  const handleOpenChange = useCallback(
    (open: boolean) => {
      if (!open) {
        handleClose();
      }
    },
    [handleClose]
  );

  const registerAction = useCallback((action: ActionConfig) => {
    setActions((prev) => [...prev.filter((a) => a.id !== action.id), action]);
    return () => {
      setActions((prev) => prev.filter((a) => a.id !== action.id));
    };
  }, []);

  const clearActions = useCallback(() => {
    setActions([]);
  }, []);

  const setDirty = useCallback((dirty: boolean) => {
    setInternalDirty(dirty);
  }, []);

  const contextValue = useMemo<ActionHostContextValue>(
    () => ({
      close: handleClose,
      forceClose: onClose, // Bypass dirty check
      registerAction,
      clearActions,
      setTitle,
      setDescription,
      setLoading,
      setDirty,
      isLoading,
      isDirty,
    }),
    [handleClose, onClose, registerAction, clearActions, isLoading, isDirty]
  );

  return (
    <ActionOverlay
      variant={variant}
      isOpen={isOpen}
      onOpenChange={handleOpenChange}
      side={side}
      size={size}
      closeOnEscape={closeOnEscape}
      closeOnOverlay={closeOnOverlay}
    >
      <HostContext.Provider value={contextValue}>
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b p-4">
          <div className="flex-1">
            {title && (
              <h2 className="text-lg font-semibold leading-none tracking-tight">
                {title}
              </h2>
            )}
            {description && (
              <p className="mt-1.5 text-sm text-muted-foreground">{description}</p>
            )}
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 shrink-0"
            onClick={handleClose}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Zamknij</span>
          </Button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-4">{children}</div>

        {/* Footer */}
        <ActionFooter actions={actions} isLoading={isLoading} />
      </HostContext.Provider>
    </ActionOverlay>
  );
}
