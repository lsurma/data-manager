import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import type { ActionConfig } from '../types';

export type ActionFooterProps = {
  actions: ActionConfig[];
  isLoading?: boolean;
};

export function ActionFooter({ actions, isLoading = false }: ActionFooterProps) {
  if (actions.length === 0) {
    return null;
  }

  const leftActions = actions.filter((a) => a.position === 'left');
  const rightActions = actions.filter((a) => a.position !== 'left');

  return (
    <div className="flex items-center justify-between gap-2 border-t p-4">
      <div className="flex gap-2">
        {leftActions.map((action) => (
          <ActionButton key={action.id} action={action} globalLoading={isLoading} />
        ))}
      </div>
      <div className="flex gap-2">
        {rightActions.map((action) => (
          <ActionButton key={action.id} action={action} globalLoading={isLoading} />
        ))}
      </div>
    </div>
  );
}

type ActionButtonProps = {
  action: ActionConfig;
  globalLoading: boolean;
};

function ActionButton({ action, globalLoading }: ActionButtonProps) {
  const isLoading = action.loading || globalLoading;
  const isDisabled = action.disabled || isLoading;

  return (
    <Button
      variant={action.variant ?? 'default'}
      disabled={isDisabled}
      onClick={action.onClick}
    >
      {action.loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
      {action.icon && !action.loading && (
        <span className="mr-2">{action.icon}</span>
      )}
      {action.label}
    </Button>
  );
}
