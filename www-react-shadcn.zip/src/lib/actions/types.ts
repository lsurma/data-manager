import type * as React from 'react';
import type { UseFormReturn, FieldValues } from 'react-hook-form';

// Warianty - uproszczone
export type PanelVariant = 'sheet' | 'dialog';
export type SheetSide = 'left' | 'right' | 'top' | 'bottom';
export type PanelSize = 'sm' | 'md' | 'lg' | 'xl' | 'full';

// Akcje w footerze
export type ActionConfig = {
  id: string;
  label: string;
  onClick: () => void | Promise<void>;
  variant?: 'default' | 'destructive' | 'outline' | 'ghost' | 'secondary';
  position?: 'left' | 'right';
  loading?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
};

// Opcje panelu
export type ActionPanelOptions<TData = unknown> = {
  isOpen: boolean;
  onClose: () => void;
  data?: TData;

  // Konfiguracja
  title?: string;
  description?: string;
  variant?: PanelVariant;
  side?: SheetSide; // tylko dla sheet
  size?: PanelSize;

  // Akcje
  actions?: ActionConfig[];

  // Dirty state
  isDirty?: boolean; // explicit override
  onDirtyClose?: 'confirm' | 'block' | 'allow'; // default: 'confirm'

  // Zachowanie
  closeOnEscape?: boolean;
  closeOnOverlay?: boolean;
};

// Props dla contentu
export type ActionContentProps<TData> = {
  data: TData | null; // null dla create mode
};

// Context dla hosta
export type ActionHostContextValue = {
  close: () => void;
  forceClose: () => void; // Close without dirty check (for save handlers)
  registerAction: (action: ActionConfig) => () => void;
  clearActions: () => void;
  setTitle: (title: string) => void;
  setDescription: (description: string) => void;
  setLoading: (loading: boolean) => void;
  setDirty: (dirty: boolean) => void; // manual override
  isLoading: boolean;
  isDirty: boolean;
};

// useConfirm types
export type ConfirmOptions = {
  title: string;
  description?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'default' | 'destructive';
};

export type ConfirmResult = 'confirm' | 'cancel';

// Panel registration
export type PanelRegistration = {
  id: string;
  options: ActionPanelOptions;
  content: React.ReactNode;
};

// ActionFormHost props
export type ActionFormHostProps<T extends FieldValues> = {
  form: UseFormReturn<T>;
  children: React.ReactNode;
};
