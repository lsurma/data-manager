import type { ActionPanelOptions } from '../types';
import { ActionHost } from '../components/action-host';

/**
 * Creates an ActionPanel component that can be rendered inline.
 * This is a simple wrapper - the component renders itself, no registry needed.
 */
export function useActionPanel<TData = unknown>(
  options: ActionPanelOptions<TData>,
  content: React.ReactNode
): React.ReactNode {
  // Simply return the ActionHost with options and content
  // The panel renders itself - no central registry needed for basic use cases
  return <ActionHost options={options as ActionPanelOptions}>{content}</ActionHost>;
}
