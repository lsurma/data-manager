import { useState, useCallback } from 'react';

export type PanelState<TData = void> = {
  isOpen: boolean;
  data: TData | null;
  open: (data?: TData) => void;
  close: () => void;
};

export function usePanelState<TData = void>(): PanelState<TData> {
  const [isOpen, setIsOpen] = useState(false);
  const [data, setData] = useState<TData | null>(null);

  const open = useCallback((openData?: TData) => {
    setData(openData ?? null);
    setIsOpen(true);
  }, []);

  const close = useCallback(() => {
    setIsOpen(false);
    // Delay clearing data to allow exit animation
    setTimeout(() => setData(null), 300);
  }, []);

  return { isOpen, data, open, close };
}
