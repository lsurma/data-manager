import { useHostContext, useHostContextSafe } from '../context/host-context';
import type { ActionHostContextValue } from '../types';

export function useActionHost(): ActionHostContextValue {
  return useHostContext();
}

export function useActionHostSafe(): ActionHostContextValue | null {
  return useHostContextSafe();
}
