import { useConfirmContext } from '../context/confirm-context';
import type { ConfirmOptions, ConfirmResult } from '../types';

export function useConfirm(): (options: ConfirmOptions) => Promise<ConfirmResult> {
  const { confirm } = useConfirmContext();
  return confirm;
}
