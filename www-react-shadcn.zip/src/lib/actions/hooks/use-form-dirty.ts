import { useEffect } from 'react';
import type { UseFormReturn, FieldValues } from 'react-hook-form';
import { useHostContextSafe } from '../context/host-context';

/**
 * Synchronizes react-hook-form's isDirty state with ActionHost
 * Used internally by ActionFormHost
 */
export function useFormDirty<T extends FieldValues>(form: UseFormReturn<T>): void {
  const hostContext = useHostContextSafe();
  const { isDirty } = form.formState;

  useEffect(() => {
    if (hostContext) {
      hostContext.setDirty(isDirty);
    }
  }, [isDirty, hostContext]);
}
