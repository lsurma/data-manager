import { useState, useCallback, useMemo, type ReactNode } from 'react';
import { ActionContext, type ActionContextValue } from '../context/action-context';
import { ConfirmContext, type ConfirmContextValue } from '../context/confirm-context';
import { ConfirmDialog } from '../components/confirm-dialog';
import type { PanelRegistration, ConfirmOptions, ConfirmResult } from '../types';

export type ActionProviderProps = {
  children: ReactNode;
};

type ConfirmState = {
  open: boolean;
  options: ConfirmOptions;
  resolve: ((result: ConfirmResult) => void) | null;
};

export function ActionProvider({ children }: ActionProviderProps) {
  // Panel registry (kept for potential future use, but not used for rendering)
  const [panels] = useState<Map<string, PanelRegistration>>(new Map());

  // Confirm dialog state
  const [confirmState, setConfirmState] = useState<ConfirmState>({
    open: false,
    options: { title: '' },
    resolve: null,
  });

  const registerPanel = useCallback((_panel: PanelRegistration) => {
    // No-op for now - panels render themselves
    return () => {};
  }, []);

  const updatePanel = useCallback(
    (_id: string, _updates: Partial<PanelRegistration>) => {
      // No-op for now - panels render themselves
    },
    []
  );

  const unregisterPanel = useCallback((_id: string) => {
    // No-op for now - panels render themselves
  }, []);

  const confirm = useCallback(
    (options: ConfirmOptions): Promise<ConfirmResult> => {
      return new Promise<ConfirmResult>((resolve) => {
        setConfirmState({
          open: true,
          options,
          resolve,
        });
      });
    },
    []
  );

  const handleConfirmResult = useCallback((result: ConfirmResult) => {
    setConfirmState((prev) => {
      if (prev.resolve) {
        prev.resolve(result);
      }
      // Only set open to false, keep options for exit animation
      return {
        ...prev,
        open: false,
        resolve: null,
      };
    });

    // Reset options after animation completes
    setTimeout(() => {
      setConfirmState((prev) => ({
        ...prev,
        options: { title: '' },
      }));
    }, 300);
  }, []);

  const actionContextValue = useMemo<ActionContextValue>(
    () => ({
      panels,
      registerPanel,
      updatePanel,
      unregisterPanel,
    }),
    [panels, registerPanel, updatePanel, unregisterPanel]
  );

  const confirmContextValue = useMemo<ConfirmContextValue>(
    () => ({
      confirm,
    }),
    [confirm]
  );

  return (
    <ActionContext.Provider value={actionContextValue}>
      <ConfirmContext.Provider value={confirmContextValue}>
        {children}

        {/* Confirm dialog */}
        <ConfirmDialog
          open={confirmState.open}
          options={confirmState.options}
          onResult={handleConfirmResult}
        />
      </ConfirmContext.Provider>
    </ActionContext.Provider>
  );
}
