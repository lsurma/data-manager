import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { MoreHorizontal, Pencil, Trash2, Copy, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  ActionProvider,
  ActionHost,
  usePanelState,
  useActionHost,
  ActionFormHost,
  useConfirm,
} from '@/lib/actions';

// =============================================================================
// PRZYKŁAD: Menu Drawer → Edit Form Drawer (z dirty state)
// =============================================================================

type OrderData = {
  id: string;
  customer: string;
  email: string;
  total: number;
  status: 'pending' | 'completed' | 'cancelled';
};

// Przykładowe dane zamówień
const sampleOrders: OrderData[] = [
  { id: '001', customer: 'Jan Kowalski', email: 'jan@example.com', total: 150.0, status: 'pending' },
  { id: '002', customer: 'Anna Nowak', email: 'anna@example.com', total: 299.99, status: 'completed' },
  { id: '003', customer: 'Piotr Wiśniewski', email: 'piotr@example.com', total: 75.5, status: 'cancelled' },
];

// Formularz edycji zamówienia (z dirty state)
type OrderFormData = {
  customer: string;
  email: string;
  total: string;
  status: 'pending' | 'completed' | 'cancelled';
};

function OrderEditForm({ order, onSaved }: { order: OrderData; onSaved: () => void }) {
  const { close, forceClose, registerAction, setTitle, setLoading } = useActionHost();

  const form = useForm<OrderFormData>({
    defaultValues: {
      customer: order.customer,
      email: order.email,
      total: order.total.toString(),
      status: order.status,
    },
  });

  useEffect(() => {
    setTitle(`Edycja zamówienia #${order.id}`);

    const unregisterSave = registerAction({
      id: 'save',
      label: 'Zapisz zmiany',
      onClick: async () => {
        setLoading(true);
        // Symulacja zapisu
        await new Promise((r) => setTimeout(r, 800));
        setLoading(false);
        onSaved();
        forceClose();
      },
    });

    const unregisterCancel = registerAction({
      id: 'cancel',
      label: 'Anuluj',
      variant: 'outline',
      position: 'left',
      onClick: close,
    });

    return () => {
      unregisterSave();
      unregisterCancel();
    };
  }, [order, close, forceClose, registerAction, setTitle, setLoading, onSaved]);

  return (
    <ActionFormHost form={form}>
      <div className="space-y-4">
        <div>
          <label className="text-sm font-medium">Klient</label>
          <input
            {...form.register('customer')}
            className="mt-1 block w-full rounded-md border px-3 py-2"
          />
        </div>
        <div>
          <label className="text-sm font-medium">Email</label>
          <input
            {...form.register('email')}
            type="email"
            className="mt-1 block w-full rounded-md border px-3 py-2"
          />
        </div>
        <div>
          <label className="text-sm font-medium">Kwota (PLN)</label>
          <input
            {...form.register('total')}
            type="number"
            step="0.01"
            className="mt-1 block w-full rounded-md border px-3 py-2"
          />
        </div>
        <div>
          <label className="text-sm font-medium">Status</label>
          <select
            {...form.register('status')}
            className="mt-1 block w-full rounded-md border px-3 py-2"
          >
            <option value="pending">Oczekujące</option>
            <option value="completed">Zrealizowane</option>
            <option value="cancelled">Anulowane</option>
          </select>
        </div>

        <div className="rounded-md bg-muted p-3 text-sm">
          <strong>Dirty state:</strong> {form.formState.isDirty ? '🔴 Tak (niezapisane zmiany)' : '🟢 Nie'}
        </div>
      </div>
    </ActionFormHost>
  );
}

// Menu drawer dla zamówienia
function OrderMenuContent({ order }: { order: OrderData }) {
  const { close, setTitle, setDescription } = useActionHost();
  const confirm = useConfirm();
  const editPanel = usePanelState<OrderData>();

  useEffect(() => {
    setTitle(`Zamówienie #${order.id}`);
    setDescription(`${order.customer} • ${order.total.toFixed(2)} PLN`);

    // Brak footera w menu - używamy tylko listy akcji w contencie
    return () => {};
  }, [order, setTitle, setDescription]);

  const handleEdit = () => {
    editPanel.open(order);
  };

  const handleDelete = async () => {
    const result = await confirm({
      title: 'Usunąć zamówienie?',
      description: `Zamówienie #${order.id} zostanie trwale usunięte.`,
      confirmLabel: 'Usuń',
      cancelLabel: 'Anuluj',
      variant: 'destructive',
    });
    if (result === 'confirm') {
      // Symulacja usunięcia
      alert(`Zamówienie #${order.id} usunięte!`);
      close();
    }
  };

  const handleDuplicate = () => {
    alert(`Zamówienie #${order.id} zduplikowane!`);
    close();
  };

  const handleView = () => {
    alert(`Podgląd zamówienia #${order.id}`);
    close();
  };

  return (
    <>
      <div className="space-y-1">
        <MenuButton icon={<Eye className="h-4 w-4" />} onClick={handleView}>
          Podgląd
        </MenuButton>
        <MenuButton icon={<Pencil className="h-4 w-4" />} onClick={handleEdit}>
          Edytuj
        </MenuButton>
        <MenuButton icon={<Copy className="h-4 w-4" />} onClick={handleDuplicate}>
          Duplikuj
        </MenuButton>
        <div className="my-2 border-t" />
        <MenuButton
          icon={<Trash2 className="h-4 w-4" />}
          onClick={handleDelete}
          variant="destructive"
        >
          Usuń
        </MenuButton>
      </div>

      {/* Edit form drawer - zagnieżdżony */}
      <ActionHost
        options={{
          isOpen: editPanel.isOpen,
          onClose: editPanel.close,
          variant: 'sheet',
          side: 'right',
          size: 'md',
        }}
      >
        {editPanel.data && (
          <OrderEditForm
            order={editPanel.data}
            onSaved={() => {
              // Po zapisaniu zamykamy też menu
              close();
            }}
          />
        )}
      </ActionHost>
    </>
  );
}

// Przycisk w menu
function MenuButton({
  children,
  icon,
  onClick,
  variant = 'default'
}: {
  children: React.ReactNode;
  icon: React.ReactNode;
  onClick: () => void;
  variant?: 'default' | 'destructive';
}) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left text-sm transition-colors ${
        variant === 'destructive'
          ? 'text-destructive hover:bg-destructive/10'
          : 'hover:bg-muted'
      }`}
    >
      {icon}
      {children}
    </button>
  );
}

// Tabela zamówień z przyciskami menu
function OrdersTable() {
  const menuPanel = usePanelState<OrderData>();

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle>Zamówienia</CardTitle>
        <CardDescription>
          Kliknij ikonę menu aby otworzyć drawer z akcjami
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="px-4 py-3 text-left text-sm font-medium">ID</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Klient</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Kwota</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                <th className="px-4 py-3 text-right text-sm font-medium">Akcje</th>
              </tr>
            </thead>
            <tbody>
              {sampleOrders.map((order) => (
                <tr key={order.id} className="border-b last:border-0">
                  <td className="px-4 py-3 text-sm font-mono">#{order.id}</td>
                  <td className="px-4 py-3 text-sm">{order.customer}</td>
                  <td className="px-4 py-3 text-sm">{order.total.toFixed(2)} PLN</td>
                  <td className="px-4 py-3 text-sm">
                    <StatusBadge status={order.status} />
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => menuPanel.open(order)}
                    >
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
      <CardFooter>
        <p className="text-xs text-muted-foreground">
          Menu → Edytuj → zmień dane → Escape/X → potwierdzenie dirty state
        </p>
      </CardFooter>

      {/* Menu drawer */}
      <ActionHost
        options={{
          isOpen: menuPanel.isOpen,
          onClose: menuPanel.close,
          variant: 'sheet',
          side: 'right',
          size: 'sm',
        }}
      >
        {menuPanel.data && <OrderMenuContent order={menuPanel.data} />}
      </ActionHost>
    </Card>
  );
}

function StatusBadge({ status }: { status: OrderData['status'] }) {
  const styles = {
    pending: 'bg-yellow-100 text-yellow-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
  };
  const labels = {
    pending: 'Oczekujące',
    completed: 'Zrealizowane',
    cancelled: 'Anulowane',
  };
  return (
    <span className={`rounded-full px-2 py-1 text-xs font-medium ${styles[status]}`}>
      {labels[status]}
    </span>
  );
}

// =============================================================================
// STARE DEMO (zachowane)
// =============================================================================

type DemoFormData = {
  name: string;
  email: string;
};

function DemoSheetContent({ data }: { data: string | null }) {
  const { close, forceClose, registerAction, setTitle } = useActionHost();
  const form = useForm<DemoFormData>({
    defaultValues: {
      name: data ?? '',
      email: '',
    },
  });

  useEffect(() => {
    setTitle(data ? `Edycja: ${data}` : 'Nowy element');

    const unregisterSave = registerAction({
      id: 'save',
      label: 'Zapisz',
      onClick: async () => {
        await new Promise((r) => setTimeout(r, 500));
        forceClose();
      },
    });

    const unregisterCancel = registerAction({
      id: 'cancel',
      label: 'Anuluj',
      variant: 'outline',
      position: 'left',
      onClick: close,
    });

    return () => {
      unregisterSave();
      unregisterCancel();
    };
  }, [data, close, forceClose, registerAction, setTitle, form]);

  return (
    <ActionFormHost form={form}>
      <div className="space-y-4">
        <div>
          <label className="text-sm font-medium">Nazwa</label>
          <input
            {...form.register('name')}
            className="mt-1 block w-full rounded-md border px-3 py-2"
            placeholder="Wpisz nazwę..."
          />
        </div>
        <div>
          <label className="text-sm font-medium">Email</label>
          <input
            {...form.register('email')}
            type="email"
            className="mt-1 block w-full rounded-md border px-3 py-2"
            placeholder="email@example.com"
          />
        </div>
        <p className="text-sm text-muted-foreground">
          Dirty state: {form.formState.isDirty ? 'Tak' : 'Nie'}
        </p>
      </div>
    </ActionFormHost>
  );
}

function NestedSheetContent({ onClose }: { onClose: () => void }) {
  const { registerAction } = useActionHost();

  useEffect(() => {
    const unregister = registerAction({
      id: 'close-nested',
      label: 'Zamknij zagnieżdżony',
      onClick: onClose,
    });
    return unregister;
  }, [registerAction, onClose]);

  return <p>To jest zagnieżdżony panel. Naciśnij Escape aby zamknąć.</p>;
}

function NestedSheetDemo() {
  const { close, registerAction, setTitle } = useActionHost();
  const nestedPanel = usePanelState<void>();

  useEffect(() => {
    setTitle('Panel główny');

    const unregisterNested = registerAction({
      id: 'open-nested',
      label: 'Otwórz zagnieżdżony',
      onClick: () => nestedPanel.open(),
    });

    const unregisterClose = registerAction({
      id: 'close',
      label: 'Zamknij',
      variant: 'outline',
      position: 'left',
      onClick: close,
    });

    return () => {
      unregisterNested();
      unregisterClose();
    };
  }, [close, registerAction, setTitle, nestedPanel]);

  return (
    <>
      <div className="space-y-4">
        <p>To jest panel główny. Możesz otworzyć zagnieżdżony panel.</p>
        <p className="text-sm text-muted-foreground">
          Escape zamknie tylko górny panel (dzięki Radix DismissableLayer).
        </p>
      </div>

      <ActionHost
        options={{
          isOpen: nestedPanel.isOpen,
          onClose: nestedPanel.close,
          title: 'Zagnieżdżony panel',
          description: 'To jest panel wewnątrz panelu',
          variant: 'sheet',
          side: 'right',
          size: 'sm',
        }}
      >
        <NestedSheetContent onClose={nestedPanel.close} />
      </ActionHost>
    </>
  );
}

function DialogDemoContent() {
  const { close, registerAction, setTitle } = useActionHost();

  useEffect(() => {
    setTitle('Dialog');

    const unregisterConfirm = registerAction({
      id: 'confirm',
      label: 'OK',
      onClick: close,
    });

    const unregisterCancel = registerAction({
      id: 'cancel',
      label: 'Anuluj',
      variant: 'outline',
      position: 'left',
      onClick: close,
    });

    return () => {
      unregisterConfirm();
      unregisterCancel();
    };
  }, [close, registerAction, setTitle]);

  return (
    <p>To jest zawartość dialogu. Możesz go zamknąć przyciskiem lub Escape.</p>
  );
}

function ConfirmDemo() {
  const confirm = useConfirm();

  const handleDelete = async () => {
    const result = await confirm({
      title: 'Usunąć element?',
      description: 'Ta operacja jest nieodwracalna.',
      confirmLabel: 'Usuń',
      cancelLabel: 'Anuluj',
      variant: 'destructive',
    });

    if (result === 'confirm') {
      alert('Element usunięty!');
    }
  };

  return (
    <Button variant="destructive" onClick={handleDelete}>
      Usuń (z potwierdzeniem)
    </Button>
  );
}

function ActionPanelDemo() {
  const sheetPanel = usePanelState<string>();
  const nestedPanel = usePanelState<void>();
  const dialogPanel = usePanelState<void>();

  return (
    <>
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Action Panel System</CardTitle>
          <CardDescription>
            Demonstracja systemu paneli (sheet, dialog)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <p className="text-sm font-medium">Warianty panelu:</p>
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => sheetPanel.open('Test')}>
                Sheet (z danymi)
              </Button>
              <Button variant="outline" onClick={() => sheetPanel.open()}>
                Sheet (bez danych)
              </Button>
              <Button variant="secondary" onClick={() => dialogPanel.open()}>
                Dialog
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-sm font-medium">Zagnieżdżone panele:</p>
            <Button onClick={() => nestedPanel.open()}>Otwórz z nested</Button>
          </div>

          <div className="space-y-2">
            <p className="text-sm font-medium">Standalone confirm:</p>
            <ConfirmDemo />
          </div>
        </CardContent>
        <CardFooter>
          <p className="text-xs text-muted-foreground">
            Dirty state + Escape handling działa automatycznie
          </p>
        </CardFooter>
      </Card>

      <ActionHost
        options={{
          isOpen: sheetPanel.isOpen,
          onClose: sheetPanel.close,
          variant: 'sheet',
          side: 'right',
          size: 'md',
        }}
      >
        <DemoSheetContent data={sheetPanel.data} />
      </ActionHost>

      <ActionHost
        options={{
          isOpen: nestedPanel.isOpen,
          onClose: nestedPanel.close,
          variant: 'sheet',
          side: 'right',
          size: 'lg',
        }}
      >
        <NestedSheetDemo />
      </ActionHost>

      <ActionHost
        options={{
          isOpen: dialogPanel.isOpen,
          onClose: dialogPanel.close,
          variant: 'dialog',
          size: 'md',
        }}
      >
        <DialogDemoContent />
      </ActionHost>
    </>
  );
}

// =============================================================================
// MAIN APP
// =============================================================================

function App() {
  return (
    <ActionProvider>
      <div className="min-h-screen bg-background p-8">
        <div className="mx-auto max-w-4xl space-y-8">
          <h1 className="text-2xl font-bold">Action Panel System - Demo</h1>

          {/* NOWY PRZYKŁAD: Menu → Form z dirty state */}
          <section>
            <h2 className="mb-4 text-lg font-semibold text-muted-foreground">
              Przykład: Data Grid → Menu Drawer → Edit Form (dirty state)
            </h2>
            <OrdersTable />
          </section>

          {/* Stare demo */}
          <section>
            <h2 className="mb-4 text-lg font-semibold text-muted-foreground">
              Podstawowe demo
            </h2>
            <ActionPanelDemo />
          </section>
        </div>
      </div>
    </ActionProvider>
  );
}

export default App;
